# Java-Parking-System
Java DBMS Project of Parking System Management

Contributors- [Rehan Shivani](https://github.com/Teriyakiboy98)

![GitHub followers](https://img.shields.io/github/followers/skyrunner360?label=Follow&style=social) ![Twitter Follow](https://img.shields.io/twitter/follow/skyrunner360?style=social)
---
## Introduction

![Alt text](./ps1.png "LogIn") 


This is a Parking management system created in java.
It can Charge and assign parking space to the vehicles entering the parkig lot and also keep their timely Record.

![Alt text](./ps2.png "Interface")


![GitHub last commit](https://img.shields.io/github/last-commit/skyrunner360/Java-Parking-System)

It is designed for the parking manager to be controlled by but administrator of the parking system can also control this in order to seek any flaw by the manager.
